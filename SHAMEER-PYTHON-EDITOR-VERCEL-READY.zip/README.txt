SHAMEER PYTHON EDITOR — VERCEL DEPLOY PACKAGE

PACKAGE CONTENTS
- index.html: complete single-page editor (original app source preserved)
- vercel.json: Vercel static deployment configuration

DEPLOY WITH VERCEL
1. Extract this ZIP. Do not upload the ZIP as a single file.
2. Put index.html and vercel.json together in the project root.
3. Import the folder/repository into Vercel (or deploy the extracted folder with Vercel CLI).
4. Framework Preset: Other
5. Build Command: leave empty
6. Output Directory: leave empty (or use . if the dashboard requires a value)
7. Install Command: leave empty
8. Deploy.

IMPORTANT
- This is a static HTML app. It does not need PHP, Node server code, or a build step.
- The editor loads CodeMirror and Pyodide from public CDNs, so users need internet access.
- Python packages are limited to packages supported by Pyodide/browser WebAssembly. Desktop GUI modules such as tkinter are not supported in a browser.
